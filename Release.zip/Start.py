import PhotoScan
import os
from urllib.parse import urlencode
from urllib.request import Request, urlopen

global url
url = 'http://localhost:3333/'

def send(message, percent):
	post_fields = {'message':message, 'percent':percent}

	request = Request(url, urlencode(post_fields).encode())
	json = urlopen(request)

doc = PhotoScan.app.document

chunk = doc.addChunk()

path_photos = "##ImageFolder##"
print("loading Photos:0")
image_list = os.listdir(path_photos)
photo_list = list()
for photo in image_list:
	if photo.rsplit(".",1)[1].lower() in  ["jpg", "jpeg", "tif", "tiff"]:
		photo_list.append("/".join([path_photos, photo]))
chunk.addPhotos(photo_list)

send("Masking Images", 10)

global mask_list
mask_list = list()

mask_list = list(chunk.cameras)
processed = 0
for camera in mask_list:
	
		for frame in camera.frames:
			print(frame)
			mask = PhotoScan.utils.createDifferenceMask(frame.photo.image(), ##MaskColor##, ##MaskTolerance##, False)
			m = PhotoScan.Mask()
			m.setImage(mask)
			frame.mask = m
			processed += 1
			send("Masking Images", int(processed / len(mask_list) / len(chunk.frames) * 100))

send("Matching Photos", 20)
chunk.matchPhotos(accuracy=##MatchPhotoAccuracy##, generic_preselection=True,reference_preselection=False,filter_mask=True)

send("Aligning Photos", 30)
chunk.alignCameras()

send("Building Dense Cloud", 40)
chunk.buildDenseCloud(quality=##DenseCloudQuality##)

send("Building Model", 60)
chunk.buildModel(surface=PhotoScan.Arbitrary, interpolation=PhotoScan.EnabledInterpolation)

send("Building UVs", 70)
chunk.buildUV(mapping=PhotoScan.GenericMapping)

send("Building Textures", 80)
chunk.buildTexture(blending=PhotoScan.MosaicBlending, size=##TextureSize##)

send("Exporting Model", 90)
chunk.exportModel(r"##ModelOutputPath##", texture_format=##TextureFormat##)

send("Agisoft Ready", 100)