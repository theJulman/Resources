﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MahApps.Metro.Controls;
using System.IO;
using System.Windows.Forms;
using MessageBox = System.Windows.MessageBox;
using OpenFileDialog = Microsoft.Win32.OpenFileDialog;

namespace ScanManager
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : MetroWindow
    {
        private Process p;

        private string AgisoftPath = @"Z:\Program Files\Agisoft\PhotoScan Pro\photoscan.exe";
        private string ZbrushPath = @"Z:\Program Files\Pixologic\ZBrush 2018\ZBrush.exe";
        private string MaxPath = @"Z:\Program Files\Autodesk\3ds Max 2017\3dsmax.exe";
        private string FBXConverterPath = @"Z:\Program Files\Autodesk\FBX\FBX Converter\2013.3\bin\FbxConverter.exe";

        public MainWindow()
        {
            InitializeComponent();
            var httpListener = new HttpListener();
            var simpleServer = new WebServer(httpListener, "http://localhost:80/", newMessage);
            simpleServer.Start();
        }

        public static byte[] newMessage(string message)
        {
            if (message != "")
            {
                message = message.Split('=')[1];

            }
            return new byte[0];
        }

        private void BStart_OnClick(object sender, RoutedEventArgs e)
        {
            AgisoftProcess();
        }

        void AgisoftProcess()
        {
            ProgressText.Header = "Current: Agisoft";
            createAgisoftScript(Environment.CurrentDirectory + @"\Output\ModelAgisoft.obj");
            startProcess(AgisoftPath, delegate
            {
                File.Delete(Environment.CurrentDirectory + @"\Temp.py");
                this.Dispatcher.Invoke(() => { ZbrushProcess(); });
            }, "-r " + Environment.CurrentDirectory + @"\Temp.py");
        }

        void createAgisoftScript(string ModelOutputPath)
        {
            string current = File.ReadAllText(Environment.CurrentDirectory+@"\Start.py");
            current = current.Replace("##ModelOutputPath##", ModelOutputPath);
            current = current.Replace("##ImageFolder##", tbImageFolder.Text);
            File.WriteAllText(Environment.CurrentDirectory+@"\Temp.py", current);
        }

        void ZbrushProcess()
        {
            ProgressText.Header = "Current: ZBRUSH";
            createZbrushScript();
            startProcess(ZbrushPath, delegate
            {
                this.Dispatcher.Invoke(() => { ProgressText.Header = "Current: Converting Models"; });
                ConvertModels(Environment.CurrentDirectory + @"\Output\ModelZbrushLow.obj", Environment.CurrentDirectory + @"\Output\ModelZbrushLow.fbx",
                    delegate
                    {
                        ConvertModels(Environment.CurrentDirectory + @"\Output\ModelZbrushHigh.obj", Environment.CurrentDirectory + @"\Output\ModelZbrushHigh.fbx", delegate{ this.Dispatcher.Invoke(() => { MaxProcess(); }); });
                    });
            }, Environment.CurrentDirectory+@"\Zbrush.txt");
        }

        void createZbrushScript()
        {
            string current = File.ReadAllText(Environment.CurrentDirectory + @"\Zbrush.txt");
            //Replace Variables
            File.WriteAllText(Environment.CurrentDirectory+@"\Temp.txt", current);
        }

        private void ConvertModels(string SourceFile, string DestinationFile, EventHandler handler)
        {
            startProcess(FBXConverterPath, handler, SourceFile + " " + DestinationFile+" /sffOBJ /dffFBX");
        }

        void MaxProcess()
        {
            ProgressText.Header = "Current: 3DS MAX";
            createMaxScript();
            startProcess(MaxPath, delegate { this.Dispatcher.Invoke(() => { finished(); }); }, "-U MAXScript "+Environment.CurrentDirectory+@"\Temp.ms");
        }

        void createMaxScript()
        {
            string current = File.ReadAllText(Environment.CurrentDirectory + @"\Scan.ms");
            current = current.Replace("##ModelFileName##", tbModelFileName.Text.Replace(@"\", @"\\"));
            File.WriteAllText(Environment.CurrentDirectory + @"\Temp.ms", current);
        }

        void startProcess(string filename, EventHandler handler, string arguments = "")
        {
            p = new Process();
            p.StartInfo.FileName = filename;
            p.StartInfo.Arguments = arguments;
            p.EnableRaisingEvents = true;
            p.StartInfo.CreateNoWindow = true;
            p.Exited += handler;
            p.Start();
        }

        void finished()
        {
            ProgressText.Header = "Success";
        }

        private void AddImageFolderButton_OnClick(object sender, RoutedEventArgs e)
        {
            using (System.Windows.Forms.FolderBrowserDialog dia = new FolderBrowserDialog())
            {
                if (dia.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    tbImageFolder.Text = dia.SelectedPath;
                }
            }
        }

        private void SaveModelButton_OnClick(object sender, RoutedEventArgs e)
        {
            using (SaveFileDialog dia = new SaveFileDialog())
            {
                if (dia.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    tbModelFileName.Text = dia.FileName;
                }
            }
        }
    }
}
